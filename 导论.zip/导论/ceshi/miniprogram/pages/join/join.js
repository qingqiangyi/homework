var that
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    content: '',
    yue: '',
    ri: '',
    hour: '',
    minute: '',
    task: '',
    commu: '',
    last:'',
    user: {},
    isLike: false,
  },
  /**
    * 生命周期函数--监听页面加载
    */
  onLoad: function (options) {
    that = this
    that.jugdeUserLogin();
  },
  /**
   * 获取填写的内容
   */
  getTextAreaContent: function (event) {
    that.data.content = event.detail.value;
  },
  getTextAreaContent2: function (event) {
    that.data.commu = event.detail.value;
    console.log(event)
  },
  task: function (e) {
    var task = e.detail.value
    that.setData({
      task: task
    })
  },
  yue: function (e) {
    var yue = e.detail.value
    that.setData({
      yue: yue
    })
  },
  ri: function (e) {
    var ri = e.detail.value
    that.setData({
      ri: ri
    })
  },
  hour: function (e) {
    var hour = e.detail.value
    that.setData({
      hour: hour
    })
  },
  minute: function (e) {
    var minute = e.detail.value
    that.setData({
      minute: minute
    })
  }, 
  last: function (e) {
    var last = e.detail.value
    that.setData({
      last: last
    })
  },


  /**
   * 发布
   */
  formSubmit: function (e) {

    this.data.content = e.detail.value['input-content'];
    if (this.data.canIUse) {
      if (this.data.content.trim() != '') {
        this.saveDataToServer();
      } else {
        wx.showToast({
          icon: 'none',
          title: '写点东西吧',
        })
      }
    } else {
      this.jugdeUserLogin();
    }
  },
  /**
   * 保存到发布集合中
   */
  saveDataToServer: function (event) {
    wx.showLoading({
      title: '上传中',
    })
   db.collection('newjoin').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        content: that.data.content,
        commu: that.data.commu,
        ri: that.data.ri,
        yue: that.data.yue,
        hour: that.data.hour,
        minute: that.data.minute,
        task: that.data.task,
        last:that.data.last,
        date: new Date(),
        user: that.data.user,
        isLike: that.data.isLike,
      },
      success: function (res) {
        // 保存到发布历史
        that.saveToHistoryServer();
        // 清空数据
        that.data.content = "";

        that.setData({
          textContent: '',
          textContent2: '',
        })

        that.showTipAndSwitchTab();

      },
    })
  },
  /**
   * 添加成功添加提示，切换页面*/

  showTipAndSwitchTab: function (event) {
    wx.showToast({
      title: '新增记录成功',
    })
    wx.switchTab({
      url: '../chat/chat',
    })
  },

  /**
   * 添加到发布集合中
   */
  saveToHistoryServer: function (event) {
    db.collection('history').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        content: that.data.content,
        date: new Date(),
        user: that.data.user,
        isLike: that.data.isLike,
      },
      success: function (res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        console.log(res)
      },
      fail: console.error
    })
  },


  /**
   * 判断用户是否登录
   */
  jugdeUserLogin: function (event) {
    // 查看是否授权
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function (res) {

              that.data.user = res.userInfo;
              console.log(that.data.user)
            }
          })
        }
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})