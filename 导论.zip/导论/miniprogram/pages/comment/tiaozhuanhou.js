// pages/evaluate/index.js
const app = getApp()
const cloud = wx.cloud
const db = cloud.database()
Page({
  data: {
    name: "",
    default_score: 0,
    score: 0,
    score_text_arr: ['非常差', '差', '一般', '好', '非常好'],
    score_text: "",
    score_img_arr: [],
    upload_pic: [],
    is_upload: false,
    delete_ico: "../images/p4.png",
    camera_pic: "./camera.png",
    time: null,
    text: "",
    temp: 0
  },
  onLoad(opt) {
    console.log(opt)
    this.seData({ name: opt.name })
  },
  onLoad: function (options) {
    this._default_score(this.data.default_score);
  },
  changeName: function (e) {
    this.__data__.text = e.detail.value
  },

  _default_score: function (tauch_score = 0) {
    var score_img = [];
    var score = 0;
    for (let i = 0; i < 5; i++) {
      if (i < tauch_score) {
        score_img[i] = "../../images/p1.png"
        score = i;
      } else {
        score_img[i] = "../../images/p2.png"
      }
    }
    this.setData({
      score_img_arr: score_img,
      score_text: this.data.score_text_arr[score]
    });
  },

  onScore: function (e) {
    var score = e.currentTarget.dataset.score;
    this._default_score(score);
    this.setData({
      score: score
    })
  },

  chooseImage(e) {
    var data = this.__data__
    const that = this
    var file = "picture" + data.temp.toString()//建议这个地方加上一个唯一标识符
    var upload_pic = data.upload_pic
    data.temp = data.temp + 1
    wx.chooseImage({
      count: 1,
      sizeType: ['original'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        console.log(res)
        const filePath = res.tempFilePaths[0]
        const cloudPath = file + filePath.match(/\.[^.]+?$/)[0]
        cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)
            upload_pic.push(res.fileID)
            that.setData({
              upload_pic: upload_pic
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
          }
        })
      },
      fail: console.log
    })
  },

  //上传评论
  onSubmit: function (e) {
    wx.showLoading({
      title: '上传中',
    })
    var that = this;
    db.collection('Comments').add({
      data: {
        text: that.data.text,
        urls: that.data.upload_pic,
        score1: that.data.score
      },
      success: res => {
        wx.hideLoading();
        console.log(res);
        //直接转跳
      },
      fail: console.log
    })
  },
  //删除图片
  deletePic: function (e) {
    var pic_index = e.currentTarget.dataset.pic_index;
    var upload_pic = [];
    for (let i in this.data.upload_pic) {
      if (i != pic_index) {
        upload_pic.push(this.data.upload_pic[i])
      }
    }
    this.setData({
      upload_pic: upload_pic,
      is_upload: false
    })
  },

})

