Page({
  data: {
    text: [],
    score1: []

  },
  pinglun: function () {
    wx.navigateTo({
      url: 'tiaozhuanhou'
    })
  },
  

  chakan: function () {//在数据库里读取评论
    var that = this;
    wx.cloud.callFunction({
      name: "chakan",
      success: function (res) {

        var result = res.result.data
        console.log(result)
        var text = []
        var score1 = []
        for (var i = 0; i < result.length; i++) {
          text.push(result[i].text)
          score1.push(result[i].score1)
          var score = 0
          score = score + result[i].score1
        }
        score = score / result.length
        that.setData({
          text: text,
          score1: score1,
          score: score
        })
      }
    }
    )
  }
})
