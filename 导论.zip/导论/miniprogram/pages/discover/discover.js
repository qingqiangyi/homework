Page({

  goToClock: function (param) {
    wx.navigateTo({
      url: '/pages/study/study',
    })
  },
  goToEncourage: function (param) {
    wx.navigateTo({
      url: '/pages/encourage/encourage',
    })
  },
  
})