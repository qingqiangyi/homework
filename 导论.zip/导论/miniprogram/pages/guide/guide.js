const app = getApp()
const cloud = wx.cloud
const db = cloud.database()
Page({
  data: {
    latitude: "",
    longitude: "",
    speed: "",
    accuracy: "",
    verticalAccuracy: "",
    horizontalAccuracy: ""
  },
  
  getLocation:function(param){
    wx.navigateTo({
      url: '/pages/place/place',
    })
  },
  
  sendLocation: function () {
    var _this = this
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        console.log(res)
        var latitude0 = res.latitude
        var longitude = res.longitude
        var speed = res.speed
        var accuracy = res.accuracy
        var verticalAccuracy = res.verticalAccuracy
        var horizontalAccuracy = res.horizontalAccuracy
        _this.setData({
          latitude: latitude0,
          longitude: longitude,
          speed: speed,
          accuracy: accuracy,
          verticalAccuracy: verticalAccuracy,
          horizontalAccuracy: horizontalAccuracy
        })
        db.collection('users').add({
          data: {
            latitude: latitude0,
            longitude: longitude,
            speed: speed,
            accuracy: accuracy,
            verticalAccuracy: verticalAccuracy,
            horizontalAccuracy: horizontalAccuracy
          },
          success: function (res) {
            console.log(res)
          }
        })
      }
    })
  },


  onLoad: function () {
    if (!cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      cloud.init({
        traceUser: true,
      })
    }
  }
})