var that
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    topic: {},
    id: '',
    openid: '',
    isLike: false,
  },

  goToChat:function(param){
    wx.navigateTo({
      url: '/pages/chathouse/chathouse',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    that = this;
    that.data.id = options.id;
    that.data.openid = options.openid;
    // 获取话题信息
    db.collection('newjoin').doc(that.data.id).get({
      success: function (res) {
        that.newjoin = res.data;
        that.setData({
          newjoin: that.newjoin,
        })
      }
    })

    // 获取收藏情况
    db.collection('myjoin')
      .where({
        _openid: that.data.openid,
        _id: that.data.id

      })
      .get({
        success: function (res) {
          if (res.data.length > 0) {
            that.refreshLikeIcon(true)
          } else {
            that.refreshLikeIcon(false)
          }
        },
        fail: console.error
      })

  },

  userhead:function(){
    wx.navigateTo({
      url: '../comment/comment',
    })
  },

  /**
   * 刷新点赞icon
   */
  refreshLikeIcon(isLike) {
    that.data.isLike = isLike
    that.setData({
      isLike: isLike,
    })
  },
  /**
   * 点击
   */
  onLikeClick: function (event) {
    console.log(that.data.isLike);
    if (that.data.isLike) {
      // 需要判断是否存在
      that.removeFromCollectServer();
    } else {
      that.saveToCollectServer();
    }
  },
  /**
   * 添加到集合中
   */
  saveToCollectServer: function (event) {
    db.collection('myjoin').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        _id: that.data.id,
        date: new Date(),
      },
      success: function (res) {
        that.refreshLikeIcon(true)
        console.log(res)
      },
    })
  },
  /**
   * 从收藏集合中移除
   */
  removeFromCollectServer: function (event) {
    db.collection('myjoin').doc(that.data.id).remove({

      success: that.refreshLikeIcon(false),
    });
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})